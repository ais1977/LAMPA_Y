#pragma once
void setStampZone(int zone);
int getStampZone();