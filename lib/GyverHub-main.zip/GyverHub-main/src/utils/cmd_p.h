#pragma once
#include <Arduino.h>
#include "../config.hpp"
#include "../macro.hpp"

int GH_getCmd(const char* str);
//int GH_getCmdN(char* str);